/**************************************************************************
	MMC/SD�J�[�hSPI�A�N�Z�X�y���t�F����
		�t�@�C���T�u�V�X�e���E�f�o�C�X�h���C�o�֐� (NiosII HAL version)

		UPDATE 2011/12/28
 **************************************************************************/

// ******************************************************************* //
//     Copyright (C) 2011, J-7SYSTEM Works.  All rights Reserved.      //
//                                                                     //
// * This module is a free sourcecode and there is NO WARRANTY.        //
// * No restriction on use. You can use, modify and redistribute it    //
//   for personal, non-profit or commercial products UNDER YOUR        //
//   RESPONSIBILITY.                                                   //
// * Redistributions of source code must retain the above copyright    //
//   notice.                                                           //
// ******************************************************************* //

#ifndef __gettime_h_
#define __gettime_h_


#include "fatfs/integer.h"	/* Basic integer types */


/***** �萔�E�}�N����` ***************************************************/



/***** �\���̒�` *********************************************************/



/***** �v���g�^�C�v�錾 ***************************************************/

/* �^�C���X�^���v��Ԃ� */
DWORD get_fattime (void);



#endif
/**************************************************************************/
